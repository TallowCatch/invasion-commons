# Post-hoc retained-activity diagnostic

Computed after reading the primary confirmation result. This is not a predeclared primary endpoint or part of the completion manifest. It distinguishes partial scaling from stopping a resolved-safe original request. The mean is case-weighted and has no uncertainty interval here. Closed-loop extraction and welfare are separate outcomes.
