# Fresh-seed budgeted reviewer confirmation

Protocol: `notes/research_review/BUDGETED_REVIEWER_CONFIRMATION_PROTOCOL.md`.
Profile: `confirm`. 1920 episodes, 11249 frozen original proposals, 101241 matched reviewer decisions.
Tracking: local files, source snapshots and checksums.

## Primary decision coverage

Rates use only proposals from initially safe states. Unresolved labels are excluded from the safe/risky denominators and retained in the table.

| Game | Safe | Risky | Unresolved | Contexts with safe | Contexts with risky |
| --- | ---: | ---: | ---: | ---: | ---: |
| fishery | 694 | 63 | 0 | 64 | 63 |
| harvest | 3687 | 1368 | 923 | 64 | 62 |

## Interpretation boundary

The two strata were selected using a prior development pilot. The current population seeds are fresh; no claim transfers to other mixtures or tasks.
Contexts are the independent units. Timesteps, weather streams and paired methods are not.
The 95% context-bootstrap intervals estimate sampling variability over these policy generators; they do not cover model, threshold or game-family uncertainty.
A missing safe or risky denominator makes that rate unavailable. No p-values or equivalence claims are made.
Closed-loop outcomes are in `outcomes.csv` and `paired_contrasts.csv`; they are secondary and can rank methods differently from the immediate decisions.
The smoke profile is an engineering check only; it has no uncertainty intervals.
